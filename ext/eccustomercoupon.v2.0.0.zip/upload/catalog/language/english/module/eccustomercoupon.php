<?php 
$_['heading_title'] = 'List Customer Group Coupons';
$_['text_coupons'] = 'Coupons';
$_['text_view_list_coupons'] = 'View List Coupons';
$_['text_customer_coupons'] = 'Your Available Coupons';
$_['text_coupon_code'] = 'Coupon Code';
$_['text_coupon_name'] = 'Coupon Name';
$_['text_date_end'] = 'Date End';
$_['text_choose_coupon'] = 'Choose your coupon code:&nbsp;';
$_['text_choose_your_coupon'] = '--- Choose coupon ---';
?>