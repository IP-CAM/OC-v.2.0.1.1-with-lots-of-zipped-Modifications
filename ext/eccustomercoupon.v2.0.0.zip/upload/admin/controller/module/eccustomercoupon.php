<?php
class ControllerModuleEccustomercoupon extends Controller {
	private $error = array();

	public function install() {
		$this->language->load('module/eccustomercoupon');

		$this->load->model('eccustomercoupon/coupon');
		$this->load->model('tool/event');

		$this->model_tool_event->addEvent('ec_couponlist_in_cart', 'get.customercouponlist.cart', 'module/eccustomercoupon/listCoupons');

		$this->model_eccustomercoupon_coupon->installECModule();
	}

	public function uninstall() {
		$this->language->load('module/eccustomercoupon');

		$this->load->model('eccustomercoupon/coupon');
		$this->load->model('tool/event');

		$this->model_tool_event->deleteEvent('ec_couponlist_in_cart');
	}

	public function index() {
		$data = array();
		$this->language->load('module/eccustomercoupon');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model('eccustomercoupon/coupon');
		$this->model_eccustomercoupon_coupon->installECModule();
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$action = isset($this->request->post["action"])?$this->request->post["action"]:"";

			$this->model_setting_setting->editSetting('eccustomercoupon', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			if($action == "save_stay"){
				$this->response->redirect($this->url->link('module/eccustomercoupon', 'token=' . $this->session->data['token'], 'SSL'));
			}else{
				$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
			}
			
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_header_top'] = $this->language->get('text_header_top');
		$data['text_header_bottom'] = $this->language->get('text_header_bottom');
		$data['text_content_top'] = $this->language->get('text_content_top');
		$data['text_content_bottom'] = $this->language->get('text_content_bottom');		
		$data['text_column_left'] = $this->language->get('text_column_left');
		$data['text_column_right'] = $this->language->get('text_column_right');
        $data['text_footer_top'] = $this->language->get('text_footer_top');
		$data['text_footer_bottom'] = $this->language->get('text_footer_bottom');
        $data['text_alllayout'] = $this->language->get('text_alllayout');
		$data['text_default'] = $this->language->get('text_default');
		$data['entry_show_only_link'] = $this->language->get('entry_show_only_link');
		
		$data['entry_content'] = $this->language->get('entry_content');
		$data['entry_layout'] = $this->language->get('entry_layout');
		$data['entry_store'] = $this->language->get('entry_store');
		$data['entry_position'] = $this->language->get('entry_position');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$data['text_module_setting'] = $this->language->get('text_module_setting');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_remove'] = $this->language->get('button_remove');
		$data['button_save_stay'] = $this->language->get('button_save_stay');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_add_new_block'] = $this->language->get('button_add_new_block');
		$data['button_import_coupon'] = $this->language->get('button_import_coupon');

		$data['text_alllayout'] = $this->language->get('text_all_layout');

		$data['success'] = isset($this->session->data['success'])?$this->session->data['success']:"";
		$data['warning_error'] = isset($this->session->data['error'])?$this->session->data['error']:"";
		
		$data['tab_block'] = $this->language->get('tab_block');

		$data['positions'] = array( 'header_top',
										  'header_bottom',
										  'content_top',
										  'content_bottom',
										  'column_left',
										  'column_right',
										  'footer_top',
										  'footer_bottom'
		);

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['dimension'])) {
			$data['error_dimension'] = $this->error['dimension'];
		} else {
			$data['error_dimension'] = array();
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('module/eccustomercoupon', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
   		$data['token'] =  $this->session->data['token'];

		$data['action'] = $this->url->link('module/eccustomercoupon', 'token=' . $this->session->data['token'], 'SSL');

		$data['import_coupon_link'] = $this->url->link('module/eccustomercoupon/importform', 'token=' . $this->session->data['token'], 'SSL');
		
		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		if (isset($this->request->post['eccustomercoupon_status'])) {
			$data['eccustomercoupon_status'] = $this->request->post['eccustomercoupon_status'];
		} else {
			$data['eccustomercoupon_status'] = $this->config->get('eccustomercoupon_status');
		}

		$data['modules'] = array();

		if (isset($this->request->post['eccustomercoupon_module'])) {
			$data['modules'] = $this->request->post['eccustomercoupon_module'];
		} elseif ($this->config->get('eccustomercoupon_module')) {
			$data['modules'] = $this->config->get('eccustomercoupon_module');
		}

		$this->load->model('design/layout');

		$data['layouts'] = $this->model_design_layout->getLayouts();

		$this->load->model('setting/store');
		
		$data['stores'] = $this->model_setting_store->getStores();

		$this->load->model('design/banner');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/eccustomercoupon.tpl', $data));
	}

	public function importform() {
		$this->language->load('module/eccustomercoupon');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model('eccustomercoupon/coupon');
		$this->model_eccustomercoupon_coupon->installECModule();
		
		$json = array();

		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {

			$action = isset($this->request->post["action"])?$this->request->post["action"]:"";

			if(isset($this->request->files['importfile']['name']) and (file_exists($this->request->files['importfile']['tmp_name']))) {
	            
	            $filename = basename(html_entity_decode($this->request->files['importfile']['name'], ENT_QUOTES, 'UTF-8'));
				
				if ((utf8_strlen($filename) < 3) || (utf8_strlen($filename) > 128)) {
					$json['error'] = $this->language->get('error_filename');
				}	  	
				
				// Allowed file extension types
				$allowed = array("csv", "txt", "xls");
				
				if (!in_array(substr(strrchr($filename, '.'), 1), $allowed)) {
					$json['error'] = $this->language->get('error_filetype');
				}

	        } else {
				$json['error'] = $this->language->get('error_upload');
			}

			if (!isset($json['error'])) {

				if (is_uploaded_file($this->request->files['importfile']['tmp_name']) && file_exists($this->request->files['importfile']['tmp_name'])) {
					$ext = md5(mt_rand());
					 
					$json['filename'] = $filename . '.' . $ext;
					$json['mask'] = $filename;
					
					move_uploaded_file($this->request->files['importfile']['tmp_name'], DIR_DOWNLOAD . $filename . '.' . $ext);

				}
				
				$this->model_eccustomercoupon_coupon->importCSV( DIR_DOWNLOAD . $filename . '.' . $ext );

				$this->session->data['success'] = $this->language->get('text_success');
			} else {
				$this->session->data['error'] = $json['error'];
			}

			$this->response->redirect($this->url->link('module/eccustomercoupon', 'token=' . $this->session->data['token'], 'SSL'));
			
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_header_top'] = $this->language->get('text_header_top');
		$data['text_header_bottom'] = $this->language->get('text_header_bottom');
		$data['text_content_top'] = $this->language->get('text_content_top');
		$data['text_content_bottom'] = $this->language->get('text_content_bottom');		
		$data['text_column_left'] = $this->language->get('text_column_left');
		$data['text_column_right'] = $this->language->get('text_column_right');
        $data['text_footer_top'] = $this->language->get('text_footer_top');
		$data['text_footer_bottom'] = $this->language->get('text_footer_bottom');
        $data['text_alllayout'] = $this->language->get('text_alllayout');
		$data['text_default'] = $this->language->get('text_default');
		$data['entry_show_only_link'] = $this->language->get('entry_show_only_link');
		
		$data['entry_content'] = $this->language->get('entry_content');
		$data['entry_layout'] = $this->language->get('entry_layout');
		$data['entry_store'] = $this->language->get('entry_store');
		$data['entry_position'] = $this->language->get('entry_position');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_save_stay'] = $this->language->get('button_save_stay');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_add_new_block'] = $this->language->get('button_add_new_block');
		$data['button_import_coupon'] = $this->language->get('button_import_coupon');
		$data['text_import_coupon_heading'] = $this->language->get('text_import_coupon_heading');

		$data['text_alllayout'] = $this->language->get('text_all_layout');


 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['dimension'])) {
			$data['error_dimension'] = $this->error['dimension'];
		} else {
			$data['error_dimension'] = array();
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('module/eccustomercoupon', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
   		$data['token'] =  $this->session->data['token'];

		$data['action'] = $this->url->link('module/eccustomercoupon/importform', 'token=' . $this->session->data['token'], 'SSL');

		$data['cancel'] = $this->url->link('module/eccustomercoupon', 'token=' . $this->session->data['token'], 'SSL');

		$this->load->model('design/layout');

		$this->load->model('setting/store');
		
		$data['stores'] = $this->model_setting_store->getStores();

		$this->load->model('design/banner');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/ec_import_coupon_form.tpl', $data));

	}
	public function generateCoupon() {
		$this->language->load('module/eccustomercoupon');
		$json = array();
		try{
			$json['coupon_code'] = $this->generateRandomString(8);
		} catch(Exception $e) {
			echo $e;
		}
		$this->response->setOutput(json_encode($json));	
	}

	protected function generateRandomString($length = 10) {
		static $counter;
		/*Set counter to limit time callback function*/
		if ($counter) {
            $counter++;
        } else {
            $counter = 0;
        }
        /*end here*/

		$this->load->model('marketing/coupon');

	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, strlen($characters) - 1)];
	    }

		$coupon_info = $this->model_marketing_coupon->getCouponByCode($randomString);
		$exists = false;
		if ($coupon_info) {
			if (!isset($this->request->get['coupon_id'])) {
				$exists = true;
			} elseif ($coupon_info['coupon_id'] != $this->request->get['coupon_id'])  {
				$exists = true;
			}
		}

		if($exists) {
			/*Limit callback the functioni 50 times*/
			if($counter >= 50) {
				if($length < 10) {
					$length = (int)$length + 1;
				} else {
					$length = 10;
				}
				$counter = 0;
			}
			$randomString = $this->generateRandomString($length);
		}

	    return $randomString;
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'module/eccustomercoupon')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}
}
?>
