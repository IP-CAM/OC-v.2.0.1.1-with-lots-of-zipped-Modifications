<?php
// Heading
$_['heading_title']       = 'EC List Customer Group Coupon';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module Customer Group Coupon!';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';
$_['text_header_top']   = 'Header Top';
$_['text_header_bottom']   = 'Header Bottom';
$_['text_footer_top']   = 'Footer Top';
$_['text_footer_center']   = 'Footer Center';
$_['text_footer_bottom']   = 'Footer Bottom';
$_['entry_show_only_link'] = 'Show only link: ';
$_['text_default'] = 'Default';
$_['text_all_layout'] = 'All layout';
$_['button_add_new_block'] = 'Add new block';
$_['button_save_stay'] = 'Save & Stay';
$_['button_import_coupon'] = 'Import Coupon';
$_['tab_block'] = 'Block ';
$_['text_module_setting'] = 'Module Setting';

$_['all_page']   = 'All Page';
// Entry
$_['entry_store'] = 'Stores: ';
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Position:';
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Sort Order:';
// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module eccustomercoupon!';
?>