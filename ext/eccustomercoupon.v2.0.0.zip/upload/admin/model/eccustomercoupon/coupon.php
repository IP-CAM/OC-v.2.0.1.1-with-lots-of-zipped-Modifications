<?php
class ModelEccustomercouponCoupon extends Model {
	private $array_delimiter = ';';
	private $delimiter = ',';
	private $header_columns;

	public function installECModule() {
		$sql = " SHOW TABLES LIKE '".DB_PREFIX."coupon_customer'";
		$query = $this->db->query( $sql );
		if( count($query->rows) <=0 )
			$this->createECTables();

		$this->db->query("SELECT * FROM " . DB_PREFIX . "event WHERE `code` = 'ec_couponlist_in_cart'");
		if( count($query->rows) <=0 ) {
			
			$this->load->model('tool/event');
			$this->model_tool_event->addEvent('ec_couponlist_in_cart', 'get.customercouponlist.cart', 'module/eccustomercoupon/listCoupons');

		}
	}
	public function uninstallECModule(){
		$sql = array();

		$sql[] = "DROP TABLE IF EXISTS `".DB_PREFIX."coupon_customer`;";
		$sql[] = "DROP TABLE IF EXISTS `".DB_PREFIX."coupon_customer_group`;";
		
		foreach( $sql as $q ){
			$query = $this->db->query( $q );
		}
	}
	protected function createECTables(){
		$sql = array();

		$sql[] = "
				CREATE TABLE IF NOT EXISTS `".DB_PREFIX."coupon_customer` (
				  `coupon_id` int(11) NOT NULL DEFAULT '0',
				  `customer_id` int(11) NOT NULL DEFAULT '0',
				  PRIMARY KEY (`coupon_id`,`customer_id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
		";
		$sql[] = "
				CREATE TABLE IF NOT EXISTS `".DB_PREFIX."coupon_customer_group` (
				  `coupon_id` int(11) NOT NULL DEFAULT '0',
				  `customer_group_id` int(11) NOT NULL DEFAULT '0',
				  PRIMARY KEY (`coupon_id`,`customer_group_id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

		";
		
		foreach( $sql as $q ){
			$query = $this->db->query( $q );
		}
		
	}
	public function getCustomerGroups2($data = array()) {
					$sql = "SELECT * FROM " . DB_PREFIX . "customer_group cg LEFT JOIN " . DB_PREFIX . "customer_group_description cgd ON (cg.customer_group_id = cgd.customer_group_id) WHERE cgd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

					$implode = array();
		
					if (!empty($data['filter_name'])) {
						$implode[] = "cgd.name LIKE '%" . $this->db->escape($data['filter_name']) . "%'";
					}

					if ($implode) {
						$sql .= " AND " . implode(" AND ", $implode);
					}
					$sort_data = array(
						'cgd.name',
						'cg.sort_order'
					);
						
					if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
						$sql .= " ORDER BY " . $data['sort'];
					} else {
						$sql .= " ORDER BY cgd.name";
					}
						
					if (isset($data['order']) && ($data['order'] == 'DESC')) {
						$sql .= " DESC";
					} else {
						$sql .= " ASC";
					}
					
					if (isset($data['start']) || isset($data['limit'])) {
						if ($data['start'] < 0) {
							$data['start'] = 0;
						}			

						if ($data['limit'] < 1) {
							$data['limit'] = 20;
						}
						
						$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
					}
						
					$query = $this->db->query($sql);
					
					return $query->rows;
	}
	public function getCouponCustomers($coupon_id) {
					$coupon_customer_data = array();
					
					$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "coupon_customer WHERE coupon_id = '" . (int)$coupon_id . "'");
					
					foreach ($query->rows as $result) {
						$coupon_customer_data[] = $result['customer_id'];
					}
					
					return $coupon_customer_data;
	}
				
	public function getCouponCustomerGroups($coupon_id) {
		$coupon_customer_group_data = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "coupon_customer_group WHERE coupon_id = '" . (int)$coupon_id . "'");
		
		foreach ($query->rows as $result) {
			$coupon_customer_group_data[] = $result['customer_group_id'];
		}

		return $coupon_customer_group_data;
	}

	public function importCSV($filepath, $coupon_name = "Coupon for customer ID (%s)") {

		$this->load->model('marketing/coupon');

		$handle = $this->openFile($filepath);

		$row = 0;
		if ( $handle != null ) {

			// loop thru all rows
			while (($data = fgetcsv($handle, 110000, $this->delimiter)) !== FALSE) {
				$row++;
				// if this is the head row keep this as a column reference

				if ($row == 1) {
					$this->mapHeader($data);
					continue;
				}

				$coupon_data = array();
				$customer_id  = 0;

				$coupon_data['code'] = $this->genCouponCode( 10 );
				$coupon_data['uses_total'] = 1;
				$coupon_data['uses_customer'] = 1;
				$coupon_data['type'] = "P";
				$coupon_data['discount'] = 0;
				$coupon_data['logged'] = 1;
				$coupon_data['shipping'] = 0;
				$coupon_data['total'] = 0;
				$coupon_data['status'] = 1;
				$coupon_data['date_start'] = date("Y-m-d");
				$coupon_data['date_end'] = date("Y-m-d");
				$coupon_data['name'] = sprintf($coupon_name, $customer_id);

				// loop through each column
				foreach ($this->header_columns as $index => $keyname) {
					$keyname = strtolower($keyname);

					// switch statement incase we need to do logic depending on the column name
					switch ($keyname) {

						case "customer_id":
						case "email":
							if($keyname == "email") {
								$query = $thid->db->query("SELECT customer_id FROM ".DB_PREFIX."customer WHERE `email`='".$data[$index]."'");
								$customer_id = isset($query->row['customer_id'])?$query->row['customer_id']:(int)$data[$index];
								
							} else {
								$customer_id = (int)$data[$index];
							}
						break;

						default:
							// fgetcsv encodes everything
							$coupon_data[$keyname] = html_entity_decode($data[$index]);

						break;

					} // end switch
				} // end for
				
				$coupon_data['type'] = strtoupper($coupon_data['type']);

				// save our coupon
				$query = $this->db->query("SELECT coupon_id FROM `".DB_PREFIX."coupon` WHERE `code`='".$coupon_data['code']."'");
				$coupon_id = isset($query->row['coupon_id'])?$query->row['coupon_id']:0;

				/*updated coupon customer*/
				if($coupon_id ) {
					$this->db->query("INSERT INTO " . DB_PREFIX . "coupon_customer SET coupon_id = ".(int)$coupon_id.", customer_id = ".(int)$customer_id);
					
				} else { //Insert coupon customer
					$this->model_marketing_coupon->addCoupon( $coupon_data );
					$query = $this->db->query("SELECT coupon_id FROM `".DB_PREFIX."coupon` WHERE `code`='".$coupon_data['code']."'");
					$coupon_id = isset($query->row['coupon_id'])?$query->row['coupon_id']:0;

					$this->db->query("DELETE FROM " . DB_PREFIX . "coupon_customer WHERE coupon_id = '" . (int)$coupon_id . "' AND customer_id='".(int)$customer_id."'");

					$this->db->query("INSERT INTO " . DB_PREFIX . "coupon_customer SET coupon_id = ".(int)$coupon_id.", customer_id = ".(int)$customer_id);

				}

			} // end while
			unlink($filepath);
		}// end if


	} // end

	private function openFile($filepath) {
		$handle = null;

		if (($handle = fopen($filepath, "r")) !== FALSE) {
			return $handle;
		} else {
			return 'Error opening file ' . $filepath;
		} // end

	} // end

	private function genCouponCode($length = 10) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, strlen($characters) - 1)];
	    }
	    return $randomString;
	}

	private function mapHeader($data_array) {
		$this->header_columns = $data_array;
	}

}
?>