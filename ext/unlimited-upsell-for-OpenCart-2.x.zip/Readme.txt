====================================
OpenCart Unlimited Upsell
====================================



Supported OpenCart Versions:
============================

v2.x (and up)



What does it do:
================
- This is the free module for integration of OpenCart with "Unlimited Upsell" service from 8upsell.com



Requirements:
==============

- Registartion at the http://8upsell.com



Main features:
==============

- When customer clicks on "Checkout" button on the page of shopping cart, then appears simple and beautiful pop-up window which offers the last possibility to add to cart relevant products based on the contents of the customers shopping cart.



How to install it:
==================

- It's described here: http://docs.opencart.com/installing-3rd-party-modules



How to use:
===================

- Register at 8upsell.com service using http://opencart-apps.spur-i-t.com/8upsell/ and follow the instructions that will be given during the registration process
- copy JavaScript code which you can find in the field "Embed Code" of the section "App settings" (http://opencart-apps.spur-i-t.com/8upsell/settings) and paste it in an "Embed Code" field of the preliminary installed this module for OpenCart
- Create offers that will be offered to your customers on the �Offers� page (http://opencart-apps.spur-i-t.com/8upsell/offers) of the app



History:
========

v1.0 - 2014-11-25 - http://spur-i-t.com

- First version



License:
========

This software is free.
If you need to get a qoute for your project, request our support service or get an answer to any other question please contact us  http://spur-i-t.com/contact.php