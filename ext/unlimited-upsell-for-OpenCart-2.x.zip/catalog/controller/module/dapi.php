<?php
/**
 * Retrieves embed code and pastes it for each layout in the store.
 *
 * @author Kovalev Yury, SpurIT <contact@spur-i-t.com>
 * @copyright Copyright (c) 2012 SpurIT <contact@spur-i-t.com>, All rights reserved
 * @link http://spur-i-t.com
 * @package D API
 * @version 1.0.0
 */
class ControllerModuleDapi extends Controller
{

	public function index()
	{
		$this->load->model( 'dapi/setting' );
		$upsellConfig = $this->model_dapi_setting->getSetting( 'upsell', $this->config->get('config_store_id') );
		$data['content'] = isset( $upsellConfig[ 'upsell_embed_code' ] ) ? html_entity_decode( $upsellConfig[ 'upsell_embed_code' ] ) : '';

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/dapi.tpl')) {
			$template = $this->config->get('config_template') . '/template/module/dapi.tpl';
		} else {
			$template = 'default/template/module/dapi.tpl';
		}

		return $this->load->view($template, $data);
	}

}

?>
