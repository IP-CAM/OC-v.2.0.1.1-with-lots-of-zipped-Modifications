<?php
/**
 * Orders model.
 * Retrieve orders information.
 *
 * @author Kovalev Yury, SpurIT <contact@spur-i-t.com>
 * @copyright Copyright (c) 2012 SpurIT <contact@spur-i-t.com>, All rights reserved
 * @link http://spur-i-t.com
 * @package D API
 * @version 1.0.0
 */
class ModelDapiOrders extends Model
{

	public function getOrders( $params )
	{
		$sql = "SELECT o.*, os.name as order_status_name FROM `" . DB_PREFIX . "order` o LEFT JOIN " . DB_PREFIX . "order_status os ON (o.order_status_id = os.order_status_id) WHERE o.customer_id = '" . (int)$this->customer->getId() . "' AND os.language_id = '" . (int)$this->config->get( 'config_language_id' ) . "'";

		if ( isset( $params[ 'date_modified' ] ) && $params[ 'date_modified' ] ) {
			$sql .= " AND o.date_modified >= STR_TO_DATE('" . $this->db->escape( $params[ 'date_modified' ] ) . "', '%Y-%m-%d %H:%i:%s')";
		}

		if ( isset( $params[ 'order_status' ] ) && (int)$params[ 'order_status' ] > 0 ) {
			$sql .= " AND o.order_status_id = '" . (int)$params[ 'order_status' ] . "'";
		} else {
			$sql .= " AND o.order_status_id > '0'";
		}

		if ( isset( $params[ 'limit' ] ) ) {
			if ( $params[ 'limit' ] < 1 ) {
				$params[ 'limit' ] = 20;
			}
			$sql .= " ORDER BY o.order_id DESC LIMIT 0," . (int)$params[ 'limit' ];
		}

		$query = $this->db->query( $sql );

		return $query->rows;
	}

	public function getOrderProducts( $order_id )
	{
		$query = $this->db->query( "SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'" );

		return $query->rows;
	}

	public function getTotalOrders( $params )
	{
		$sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "order` WHERE customer_id = '" . (int)$this->customer->getId() . "'";

		if ( isset( $params[ 'date_modified' ] ) && $params[ 'date_modified' ] ) {
			$sql .= " AND date_modified >= STR_TO_DATE('" . $this->db->escape( $params[ 'date_modified' ] ) . "', '%Y-%m-%d %H:%i:%s')";
		}

		if ( isset( $params[ 'order_status' ] ) && (int)$params[ 'order_status' ] > 0 ) {
			$sql .= " AND order_status_id = '" . (int)$params[ 'order_status' ] . "'";
		} else {
			$sql .= " AND order_status_id > '0'";
		}

		$query = $this->db->query( $sql );

		return $query->row[ 'total' ];
	}

	public function getOrderStatuses()
	{
		$sql = "SELECT * FROM " . DB_PREFIX . "order_status WHERE language_id = '" . (int)$this->config->get( 'config_language_id' ) . "' ORDER BY name";
		$query = $this->db->query( $sql );

		return $query->rows;
	}
}
