<?php
	/**
	 * API token model.
	 * Manipulates tokens.
	 *
	 * @author Polyakov Ivan, SpurIT <contact@spur-i-t.com>
	 * @copyright Copyright (c) 2012 SpurIT <contact@spur-i-t.com>, All rights reserved
	 * @link http://spur-i-t.com
	 * @package D API
	 * @version 1.0.0
	 */
	class ModelDapiToken extends Model
	{
		/**
		 * Table name.
		 * @var string
		 */
		private $_name = 'dapi_tokens';

		/**
		 * Inserts new token.
		 * @param integer $storeId - store id.
		 * @param string $token - token.
		 */
		public function insert( $storeId, $token )
		{
			$storeId = (integer) $storeId;
			$token = addslashes( $token );
			$this->db->query( '
				INSERT INTO'. DB_PREFIX . $this->_name .' ( `store_id`, `token` )
				VALUES ( '. $storeId .', \''. $token .'\' )
			' );
		}

		/**
		 * Updates existing token.
		 * @param integer $storeId - store id.
		 * @param string $token - token.
		 */
		public function update( $storeId, $token )
		{
			$storeId = (integer) $storeId;
			$token = addslashes( $token );
			$this->db->query( '
				UPDATE '. DB_PREFIX . $this->_name .'
				SET `token` = \''. $token .'\'
				WHERE `store_id` = '. $storeId .'
			' );
		}

		/**
		 * Returns shop token.
		 * @param integer $storeId - store id.
		 * @return string | null
		 */
		public function get( $storeId )
		{
			$storeId = (integer) $storeId;
			$result = $this->db->query( '
				SELECT * FROM '. DB_PREFIX . $this->_name .'
				WHERE `store_id` = '. $storeId .'
				LIMIT 1
			' );
			$token = !empty ( $result->row ) ? $result->row['token'] : null;
			return $token;
		}

		/**
		 * Searches a token.
		 * @param string $token - token.
		 * @return array | null
		 */
		public function find( $token )
		{
			$token = addslashes( $token );
			$result = $this->db->query( '
				SELECT * FROM '. DB_PREFIX . $this->_name .'
				WHERE `token` = \''. $token .'\'
				LIMIT 1
			' );
			$row = !empty ( $result->row ) ? $result->row : null;
			return $row;
		}

		/**
		 * Db part of installation process.
		 */
		public function install()
		{
			$this->db->query( "
				CREATE TABLE IF NOT EXISTS `". DB_PREFIX . $this->_name ."` (
					`store_id` INTEGER(11) NOT NULL,
					`token` VARCHAR(64) NOT NULL,
					key ( `store_id` )
				) ENGINE=MyISAM CHARSET=utf8
			" );
		}

		/**
		 * Db part of uninstallation process.
		 */
		public function uninstall()
		{
			$this->db->query( "
				DROP TABLE IF EXISTS `". DB_PREFIX . $this->_name ."`
			" );
		}
	}
