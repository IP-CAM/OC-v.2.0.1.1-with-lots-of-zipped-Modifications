<?php
/**
 * API admin controller.
 * Provides with module actions.
 *
 * @author Polyakov Ivan, SpurIT <contact@spur-i-t.com>
 * @copyright Copyright (c) 2012 SpurIT <contact@spur-i-t.com>, All rights reserved
 * @link http://spur-i-t.com
 * @package D API
 * @version 1.0.1
 */
class ControllerModuleDapi extends Controller
{

	/**
	 * Error messages.
	 * @var array
	 */
	private $error = array();

	private $moduleName = 'dapi';

	/**
	 * Edit action.
	 */
	public function index()
	{
		$this->load->model( 'dapi/token' );
		$this->load->model( 'setting/setting' );
		$this->load->model( 'setting/store' );
		$this->load->language( 'module/dapi' );

		$this->document->setTitle( $this->language->get( 'heading_title' ) );

		$storeId = isset ( $this->request->post[ 'store_id' ] ) ? $this->request->post[ 'store_id' ] : 0;
		if ( ( $this->request->server[ 'REQUEST_METHOD' ] == 'POST' ) && $this->_validate() ) {
			unset( $this->request->post[ 'store_id' ] );
			$this->model_setting_setting->editSetting( 'upsell', $this->request->post, $storeId );
			$this->session->data[ 'success' ] = $this->language->get( 'text_success' );
			$this->response->redirect( $this->url->link( 'extension/module', 'token=' . $this->session->data[ 'token' ], 'SSL' ) );
		}

		$data[ 'stores' ] = $this->model_setting_store->getStores();
		$data[ 'token' ] = $this->model_dapi_token->get( 0 );
		$upsellConfig = $this->model_setting_setting->getSetting( 'upsell', $storeId );
		$data[ 'upsell_embed_code' ] = isset( $upsellConfig[ 'upsell_embed_code' ] ) ? $upsellConfig[ 'upsell_embed_code' ] : '';

		// Error.
		if ( isset ( $this->error[ 'warning' ] ) ) {
			$data[ 'error_warning' ] = $this->error[ 'warning' ];
		} else {
			$data[ 'error_warning' ] = null;
		}
		// Data.
		$data[ 'heading_title' ] = $this->language->get( 'heading_title' );
		// Breadcrumbs.
		$data[ 'breadcrumbs' ] = array(
			array(
				'text' => $this->language->get( 'home' ),
				'href' => $this->url->link(
					'common/home',
					'token=' . $this->session->data[ 'token' ],
					'SSL'
				),
				'separator' => false
			),
			array(
				'text' => $this->language->get( 'module' ),
				'href' => $this->url->link(
					'extension/module',
					'token=' . $this->session->data[ 'token' ],
					'SSL'
				),
				'separator' => '::'
			),
			array(
				'text' => $this->language->get( 'heading_title' ),
				'href' => $this->url->link(
					'module/dapi',
					'token=' . $this->session->data[ 'token' ],
					'SSL'
				),
				'separator' => '::'
			)
		);

		$data[ 'button_save' ] = $this->language->get( 'button_save' );
		$data[ 'button_cancel' ] = $this->language->get( 'button_cancel' );
		$data[ 'cancel' ] = $this->url->link( 'extension/module', 'token=' . $this->session->data[ 'token' ], 'SSL' );
		$data[ 'action' ] = $this->url->link( 'module/dapi/token', 'token=' . $this->session->data[ 'token' ], 'SSL' );
		$data[ 'embed_action' ] = $this->url->link( 'module/dapi', 'token=' . $this->session->data[ 'token' ], 'SSL' );
		$data[ 'generate_action' ] = $this->url->link( 'module/dapi/regenerate', 'token=' . $this->session->data[ 'token' ], 'SSL' );


		$data[ 'text_edit' ] = $this->language->get( 'text_edit' );
		$data[ 'store' ] = $this->language->get( 'store' );
		$data[ 'default' ] = $this->language->get( 'default' );
		$data[ 'store_note' ] = $this->language->get( 'store_note' );
		$data[ 'api_token' ] = $this->language->get( 'api_token' );
		$data[ 'generate_token' ] = $this->language->get( 'generate_token' );
		$data[ 'generation_note' ] = $this->language->get( 'generation_note' );
		$data[ 'embed_code' ] = $this->language->get( 'embed_code' );
		$data[ 'embed_note' ] = $this->language->get( 'embed_note' );
		$data[ 'regenerate_for_layouts_button' ] = $this->language->get( 'regenerate_for_layouts_button' );
		$data[ 'regenerate_for_layouts' ] = $this->language->get( 'regenerate_for_layouts' );
		$data[ 'regenerate_for_layouts_note' ] = $this->language->get( 'regenerate_for_layouts_note' );

		$data[ 'header' ] = $this->load->controller( 'common/header' );
		$data[ 'column_left' ] = $this->load->controller( 'common/column_left' );
		$data[ 'footer' ] = $this->load->controller( 'common/footer' );

		$this->response->setOutput( $this->load->view( 'module/dapi.tpl', $data ) );
	}

	/**
	 * Generates token for stores
	 */
	public function token()
	{
		$this->load->model( 'dapi/token' );
		$this->load->model( 'setting/setting' );
		$this->load->model( 'setting/store' );

		$data = array();
		// Store.
		$storeId = isset ( $this->request->post[ 'store_id' ] ) ? $this->request->post[ 'store_id' ] : 0;
		// Generate a token if was submission.
		$currentToken = $this->model_dapi_token->get( $storeId );
		if ( ( $this->request->server[ 'REQUEST_METHOD' ] == 'POST' ) && isset ( $this->request->post[ 'api_token' ] ) && $this->_validate() ) {
			$config = $this->model_setting_setting->getSetting( 'config' );
			$data[ 'token' ] = $token = hash( 'sha256', time() . $config[ 'config_encryption' ] );
			if ( $currentToken ) {
				$this->model_dapi_token->update( $storeId, $token );
			} else {
				$this->model_dapi_token->insert( $storeId, $token );
			}
			// Log
			$logger = new Log( 'dapi.log' );
			$logger->write(
				$this->language->get( 'new_token_generated' )
			);
		} else {
			$data[ 'token' ] = $currentToken;
		}
		$upsellConfig = $this->model_setting_setting->getSetting( 'upsell', $storeId );
		$data[ 'code' ] = isset( $upsellConfig[ 'upsell_embed_code' ] ) ? html_entity_decode( $upsellConfig[ 'upsell_embed_code' ] ) : '';

		$this->response->setOutput( json_encode( $data ) );
	}

	/**
	 * Update layouts for the module
	 */
	public function regenerate()
	{
		$this->_generateForLayouts();
	}

	/**
	 * Install action.
	 */
	public function install()
	{
		$this->load->model( 'dapi/token' );
		$this->model_dapi_token->install();
		$this->_generateForLayouts();
	}

	/**
	 * Uninstall action.
	 */
	public function uninstall()
	{
		$this->load->model( 'dapi/token' );
		$this->model_dapi_token->uninstall();
	}

	/**
	 * Access validation.
	 */
	protected function _validate()
	{
		if ( !$this->user->hasPermission( 'modify', 'module/dapi' ) ) {
			$this->error[ 'warning' ] = $this->language->get( 'error_permission' );
		}
		if ( !$this->error ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Generates the code that appends the javascript code  to the top content
	 */
	protected function _generateForLayouts()
	{
		if ( ( $this->request->server[ 'REQUEST_METHOD' ] == 'POST' ) ) {
			$this->load->model( 'dapi/layout' );
			$this->load->model( 'design/layout' );
			$this->load->model( 'setting/setting' );
			$layouts = $this->model_design_layout->getLayouts();
			$module = array(
				'code' => $this->moduleName,
				'position' => 'content_top',
				'sort_order' => 0
			);
			foreach ( $layouts as $layout ) {
				$this->model_dapi_layout->insert( $module, $layout[ 'layout_id' ] );
			}

			$this->model_setting_setting->editSetting( $this->moduleName, array(
				$this->moduleName . '_status' => 1
			) );
		}
	}
}

