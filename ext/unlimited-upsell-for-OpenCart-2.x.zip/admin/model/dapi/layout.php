<?php
/**
 * Layout model.
 * Register the module in the layout.
 *
 * @author Kovalev Yury, SpurIT <contact@spur-i-t.com>
 * @copyright Copyright (c) 2012 SpurIT <contact@spur-i-t.com>, All rights reserved
 * @link http://spur-i-t.com
 * @package D API
 * @version 1.0.0
 */
class ModelDapiLayout extends Model
{

	/**
	 * Insert new module row.
	 * @param array $layout_module - store id.
	 * @param integer $layout_id.
	 */
	public function insert( $layout_module, $layout_id )
	{
		$code = $this->db->escape( $layout_module[ 'code' ] );
		if ( !$this->getModule( $layout_id, $code ) )
			$this->db->query( "INSERT INTO " . DB_PREFIX . "layout_module
				SET layout_id = '" . (int)$layout_id . "',
				code = '" . $code . "',
				position = '" . $this->db->escape( $layout_module[ 'position' ] ) . "',
				sort_order = '" . (int)$layout_module[ 'sort_order' ] . "'"
			);
	}

	/**
	 * Checks an existing row
	 * @param $layout_id
	 * @param $code
	 * @return mixed
	 */
	private function getModule( $layout_id, $code )
	{
		$query = $this->db->query( "SELECT DISTINCT * FROM " . DB_PREFIX . "layout_module
			WHERE layout_id = '" . (int)$layout_id . "'
			AND code = '" . $code . "'"
		);

		return $query->row;
	}

}
