<?php
// Common.
$_[ 'home' ] = 'Home';
$_[ 'module' ] = 'Module';
$_[ 'store' ] = 'Store';
$_[ 'stores' ] = 'Stores';
$_[ 'default' ] = 'Default';

// Module.
$_[ 'generation_note' ] = 'Api Token allows access to the store contents. Each store can own only one token at once.';
$_[ 'heading_title' ] = 'Unlimited Upsell';
$_[ 'api_token' ] = 'API Token';
$_[ 'generate_token' ] = 'Generate token';
$_[ 'new_token_generated' ] = 'New token was generated.';
$_[ 'text_success' ] = 'Success: You have modified Unlimited Upsell module!';
$_[ 'error_permission' ] = 'You don\'t have permission to modify this module.';
$_[ 'store_note' ] = 'Select the store for which you need to generate Api Token';
$_[ 'embed_code' ] = 'Embed Code';
$_[ 'embed_note' ] = 'You can find this code on the field Embed Code of the section <a style="text-decoration:underline;" target="_blank" href="http://opencart-apps.spur-i-t.com/8upsell/settings">App settings</a>';
$_[ 'regenerate_for_layouts' ] = 'Refresh extension';
$_[ 'regenerate_for_layouts_button' ] = 'Refresh';
$_[ 'regenerate_for_layouts_note' ] = 'You need to refresh this extension if you make some changes in the store layouts, it maybe creation or deletion actions.';
$_[ 'button_save' ] = 'Save';
$_[ 'button_cancel' ] = 'Cancel';
$_[ 'text_edit' ] = 'Edit Unlimited Upsell Module';



