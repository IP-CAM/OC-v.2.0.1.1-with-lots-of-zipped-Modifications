﻿Watermark Large Product Images
---------------------------------
(c) MaxD, http://OpenShop.org.ua
max@bukrek.net

Watermarks large product images (popups) and main product image at product page.
Doesn't watermark thumbnails. Restricts direct access to original images.

Installation:

1. Copy files to your shop's root
2. Edit image/data/.htaccess and specify your shop's logo an icon files or delete it, 
   if you don't need to protect original images
3. Change image/watermark.png to your watermark.

Delete your image/cache/data contents to feel the watermark change.

If you want to change watermark's position, 
edit the formulas at the end of the vqmod/xml/Watermark-Large-Images.xml, its simple.