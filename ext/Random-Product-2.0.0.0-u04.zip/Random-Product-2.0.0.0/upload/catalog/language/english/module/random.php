<?php
// Heading
$_['heading_title'] = 'Random';

// Text
$_['text_tax']      = 'Ex Tax:';