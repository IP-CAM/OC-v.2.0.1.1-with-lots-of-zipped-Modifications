<?php 
$_['tweet_text'] = 'Twitter share';
$_['product_quick_view'] = 'Product Quick View';
?>