Date created: 20.10.2014
For Opencart v 2.0
Created by Alex Slipknot (alexslipknot@europe.com)

License: Free
To install upload files. Set access rights and activate module. Then edit module and set layout.