<?php
// Heading
$_['heading_title'] = 'Viewed';

// Text
$_['text_tax']      = 'Ex Tax:';