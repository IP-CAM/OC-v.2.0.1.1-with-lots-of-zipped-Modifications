<?php
class ModelCustomKryd extends Model {
  public function kryd() {

  }       
}
?>