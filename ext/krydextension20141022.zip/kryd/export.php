<?php
require_once('../config.php');
require_once('../vqmod/vqmod.php');
VQMod::bootup();
require_once(VQMod::modCheck(DIR_SYSTEM . 'startup.php'));
require_once(VQMod::modCheck(DIR_SYSTEM . 'library/customer.php'));

function xmlentities($string) {
  return str_replace(array('&','"',"'",'<', '>'),array('&amp;','&quot;','&apos;','&lt;','&gt;'),$string);
}

$registry=new Registry();
$loader=new Loader($registry);

$registry->set('load', $loader);

$config=new Config();
$registry->set('config', $config);

$db=new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
$registry->set('db', $db);

$config->set('config_language_id',1);

$registry->set('customer', new Customer($registry));


$loader->model('catalog/product');
$loader->model('tool/image');

$model=$registry->get('model_catalog_product');
$resize=$registry->get('model_tool_image');

$results=$model->getProducts(Array());

header("Content-type:text/xml");
echo '<?xml version="1.0" encoding="UTF-8" ?>'."\n";
echo "<items>\n";
foreach ($results as $item) {
  $image_link="http://".$_SERVER['SERVER_NAME']."/".$resize->resize($item["image"],100,100);
  echo "  <item>\n";
  echo "    <id>".xmlentities($item["product_id"])."</id>\n";
  echo "    <name>".xmlentities($item["name"])."</name>\n";
  echo "    <price>".xmlentities($item["price"])."</price>\n";
  echo "    <thumb>".xmlentities($image_link)."</thumb>\n";
  echo "  </item>\n";
}
echo '</items>';
?>