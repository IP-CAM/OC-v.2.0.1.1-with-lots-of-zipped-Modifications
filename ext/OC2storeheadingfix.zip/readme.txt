Hi,

Thanks for you for being one of our valuable clients
If you find this extension useful,
Rates and comments will help us to bring you more updates with new features

--
DotBox team
dotbox.sk | dotboxcreative.com 

ABOUT:
=========
 * @version 1.0
 * @author dotbox.sk | dotboxcreative.com | support@dotbox.sk 
 * @copyright (c) 2014

This extension fixes the the header in shop setting tab (System > Setting > Edit). Now it showing correct header


HOW TO INSTALL:
==================
The mod is released via ocmod, thus avoiding changes to core files OpenCart and easier maintenance (and possible rollback). 

Installation: 

1) Upload store_setting_fix.ocmod through Extensions > Extension Installer trhough opencart admin

2) Refresh the modification cache with Refresh button in Extensions > Modifications

For a rollback of the installation, you simply need to Disable or Delete the extension in Extensions > Modifications and then clear - refresh cache.

For manual rolback delete files in system\modification and Refresh the cache in admin.

CHANGELOG:
===
v1.0 (20/4/2014)
- Initial release
