<?php

// Text
$_['text_dd']       = 'Make your choice';
