<?php
// Heading
$_['heading_title']    = 'Filter: Products by color (ShopByColor)';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified ShopByColor module!';
$_['text_edit']        = 'Edit ShopByColor Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module ShopByColor!';