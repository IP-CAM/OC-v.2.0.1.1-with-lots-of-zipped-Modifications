<?php
// Heading 
$_['heading_title']  = 'Filtr: barva'; // Shop by Color | Barva zboží
?>