Hi,

Thanks for you for being one of our valuable clients
If you find this extension useful,
Rates and comments will help us to bring you more updates with new features

--
DotBox team
dotbox.sk | dotboxcreative.com 

ABOUT:
=========
 * @version 1.0
 * @author dotbox.sk | dotboxcreative.com | support@dotbox.sk 
 * @copyright (c) 2014
 * @compatible OpenCart 1.5.1-1.5.6

This extension is quite simple but really useful. It adds animated scroll to top button if the user scrolls down the page. It help Your Visitors to get to the Top of the Page.


COMPATIBILITY:
==================
OpenCart 1.5.1-1.5.6
- Compatible with other mods

DEMO:
==================
http://zxp.dotbox.sk/index.php?route=product/product&product_id=42 (guest/guest)

HOW TO INSTALL:
==================
The mod is released via ocmod, thus avoiding changes to core files OpenCart and easier maintenance (and possible rollback). 

Installation: 

1) Upload *.xml file through Extensions > Extension Installer trhough opencart admin

2) Refresh the modification cache with Refresh button in Extensions > Modifications

For a rollback of the installation, you simply need to Disable or Delete the extension in Extensions > Modifications and then clear - refresh cache.

For manual rolback delete files in system\modification and Refresh the cache in admin.




CHANGELOG:
==================
v1.1 (2/10/2014)
- OpenCart 2.0.0.0 support

v1.0 (15/7/2014)
- Initial release
