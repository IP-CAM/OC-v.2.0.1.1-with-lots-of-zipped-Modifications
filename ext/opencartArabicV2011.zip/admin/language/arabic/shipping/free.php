<?php
// Heading
$_['heading_title']    = 'شحن مجاني';

// Text
$_['text_shipping']    = 'الشحن';
$_['text_success']     = 'تم التعديل !';
$_['text_edit']        = 'تحرير';

// Entry
$_['entry_total']      = 'الاجمالي المطلوب';
$_['entry_geo_zone']   = 'المنطقة الجغرافية :';
$_['entry_status']     = 'الحالة :';
$_['entry_sort_order'] = 'ترتيب الفرز :';

// Help
$_['help_total']       = 'اكتب هنا الاجمالي المطلوب لكي يظهر الشحن المجاني للطلب.';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';