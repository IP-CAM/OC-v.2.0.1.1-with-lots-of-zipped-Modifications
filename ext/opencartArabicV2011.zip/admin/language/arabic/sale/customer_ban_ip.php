<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'حظر آي بي العملاء';

// Text
$_['text_success']     = 'تم التعديل !';
$_['text_list']        = 'قائمة';
$_['text_add']         = 'ادراج';
$_['text_edit']        = 'تحرير';

// Column
$_['column_ip']        = 'الآي بي - IP';
$_['column_customer']  = 'العملاء';
$_['column_action']    = 'تحرير';

// Entry
$_['entry_ip']         = 'الآي بي - IP';

// Error
$_['error_permission'] = 'تحذير: أنت لاتمتلك صلاحيات التعديل !';
$_['error_ip']         = 'يجب أن يكون بين 1 و 40 رمزاً !';