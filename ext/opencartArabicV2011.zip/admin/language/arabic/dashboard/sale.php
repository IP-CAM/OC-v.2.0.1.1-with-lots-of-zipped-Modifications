<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'اجمالي المبيعات';

// Text
$_['text_view']     = 'المزيد ...';