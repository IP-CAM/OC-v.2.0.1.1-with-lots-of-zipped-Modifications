<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'آخر الطلبات';

// Column
$_['column_order_id']              = 'رقم الطلب';
$_['column_customer']              = 'اسم العميل';
$_['column_status']                = 'الحالة';
$_['column_total']                 = 'الاجمالي';
$_['column_date_added']            = 'تاريخ الطلب';
$_['column_action']                = 'تحرير';