<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'عدد العملاء';

// Text
$_['text_view'] = 'المزيد ...';