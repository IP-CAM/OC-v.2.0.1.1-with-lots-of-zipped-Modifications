opencart-popular-product-slider
===============================

Open Cart Slider for Popular Products 


Needs Bootstrap and jQuery to work so make sure that you have bootstrap (both the CSS and Javascript library) added to your header.

So far I have tested this on 1.5.6 and it works fine. 

Might need some adjustments on the 

Popular Products(Most Viewed)
			
			
	Instructions
1) Copy "admin" and "catalog" folders in your website root
2) Enter Opencart Administration - Modules	
3) Install "Popular Products(Most viewed)"	

Originally created by http://shopthemer.com


http://www.opencart.com/index.php?route=extension/extension/info&extension_id=11360&filter_search=products%20most%20viewed&page=3

