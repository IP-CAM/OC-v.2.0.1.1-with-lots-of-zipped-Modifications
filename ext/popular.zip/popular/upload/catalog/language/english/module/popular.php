<?php
// Heading 
$_['heading_title'] = 'Popular';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>